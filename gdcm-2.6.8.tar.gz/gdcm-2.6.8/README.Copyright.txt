December 28, 2008

Historical note:

Starting with gdcm 2.0.11, GDCM, Grassroots DICOM is distributed
under the new simplified BSD license, approved by the Open Source Initiative (OSI)
* http://www.opensource.org/licenses/bsd-license.php

See Copyright.txt
