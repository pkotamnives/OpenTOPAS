public const string vtkgdcmEL_dll = "libKitware.VTK.vtkgdcm.Unmanaged.so";
